using PaymentAPI.Configurations;

namespace PaymentAPI.DTOs.Responses
{
    public class RegistrationResponse : AuthResult { }
}
