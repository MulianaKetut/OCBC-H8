namespace PaymentAPI.Configurations
{
    public class JwtConfig
    {
        public string Secret { get; set; }
    }
}
